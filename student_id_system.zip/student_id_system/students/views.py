# students/views.py

# from django.shortcuts import render
# from .models import Student

# def index(request):
#     students = Student.objects.all()
#     return render(request, 'students/index.html', {'students': students})
# from django.shortcuts import render
# from .models import Student

# def index(request):
#     query = request.GET.get('search', '')
#     if query:
#         students = Student.objects.filter(first_name__icontains=query) | Student.objects.filter(last_name__icontains=query)
#     else:
#         students = Student.objects.all()
#     return render(request, 'students/index.html', {'students': students})
from django.shortcuts import render
from .models import Student

def index(request):
    query = request.GET.get('search', '')
    if query:
        students = Student.objects.filter(
            student_id__icontains=query
        ) | Student.objects.filter(
            first_name__icontains=query
        ) | Student.objects.filter(
            last_name__icontains=query
        )
    else:
        students = Student.objects.all()
    return render(request, 'students/index.html', {'students': students})
